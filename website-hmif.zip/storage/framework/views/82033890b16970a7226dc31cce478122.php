<?php $__env->startSection('main-home'); ?>
    <section class="container my-5 py-4">
        <div class="row">
            <div class="col">
                <h1>Saat ini sedang tidak ada vote. Mohon tunggu Pemilihan Ketua Hima Berikutnya</h1>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.homeTemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULI AH\Semester 5\Manpro\Tubes\website-hmif\resources\views/no_vote.blade.php ENDPATH**/ ?>