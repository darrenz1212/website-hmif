<?php $__env->startSection('main-content'); ?>
    <h1>Hello World</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.starter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULI AH\Semester 5\Manpro\Tubes\website-hmif\resources\views/admin/admin.blade.php ENDPATH**/ ?>