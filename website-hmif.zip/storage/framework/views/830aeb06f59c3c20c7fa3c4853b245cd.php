<?php $__env->startSection('main-content'); ?>
    <div class="container my-5">
        <h1>Kelola Kandidat</h1>

        
        <button class="btn btn-primary mb-4" onclick="toggleForm('create')">Buat Kandidat Baru</button>

        
        <table class="table">
            <thead>
            <tr>
                <th>#</th>
                <th>No Urut</th>
                <th>Nama</th>
                <th>Gambar</th>
                <th>Visi</th>
                <th>Misi</th>
                <th>Aksi</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $candidates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $candidate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($candidate->no_urut); ?></td>
                    <td><?php echo e($candidate->nama); ?></td>
                    <td><img src="<?php echo e(asset($candidate->image)); ?>" alt="Candidate Image" class="img-thumbnail" width="100"></td>
                    <td><?php echo e($candidate->visi); ?></td>
                    <td><?php echo e($candidate->misi); ?></td>
                    <td>
                        <button class="btn btn-sm btn-info" onclick="editCandidate(<?php echo e($candidate); ?>)">Edit</button>
                        <form action="<?php echo e(route('candidates.destroy', $candidate->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-sm btn-danger">Hapus</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        
        <div id="candidate-form" style="display: none;">
            <form id="candidateForm" action="<?php echo e(route('candidates.update', 0)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <input type="hidden" name="candidate_id" id="candidate_id">

                <div class="form-group">
                    <label for="no_urut">No Urut</label>
                    <input type="number" name="no_urut" id="no_urut" class="form-control" required>
                </div>

                <div class="form-group">
                    <label for="nama">Nama</label>
                    <input type="text" name="nama" id="nama" class="form-control" required>
                </div>

                <div class="form-group">
                    <label for="visi">Visi</label>
                    <textarea name="visi" id="visi" class="form-control" rows="3" required></textarea>
                </div>

                <div class="form-group">
                    <label for="misi">Misi</label>
                    <textarea name="misi" id="misi" class="form-control" rows="3" required></textarea>
                </div>

                <div class="form-group">
                    <label for="image">Gambar</label>
                    <input type="file" name="image" id="image" class="form-control-file">
                </div>

                <button type="submit" class="btn btn-success">Simpan</button>
                <button type="button" class="btn btn-secondary" onclick="toggleForm()">Batal</button>
            </form>
        </div>
    </div>

    <script>
        function toggleForm() {
            const form = document.getElementById('candidate-form');
            form.style.display = form.style.display === 'none' ? 'block' : 'none';
        }

        function editCandidate(candidate) {
            toggleForm();
            document.getElementById('candidateForm').action = "<?php echo e(url('/candidates')); ?>/" + candidate.id;
            document.getElementById('no_urut').value = candidate.no_urut;
            document.getElementById('nama').value = candidate.nama;
            document.getElementById('visi').value = candidate.visi;
            document.getElementById('misi').value = candidate.misi;
            document.getElementById('candidate_id').value = candidate.id;
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.starter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULI AH\Semester 5\Manpro\Tubes\website-hmif\resources\views/admin/editCandidates.blade.php ENDPATH**/ ?>