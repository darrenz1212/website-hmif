<?php $__env->startSection('main-content'); ?>
    <div class="container my-5">
        <h1>Pengaturan Status Voting</h1>

        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('vote.updateStatus')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="status">Status Voting:</label>
                <select name="status" id="status" class="form-control">
                    <option value="1" <?php echo e($voteStatus && $voteStatus->status ? 'selected' : ''); ?>>Aktif</option>
                    <option value="0" <?php echo e($voteStatus && !$voteStatus->status ? 'selected' : ''); ?>>Nonaktif</option>
                </select>
            </div>

            <button type="submit" class="btn btn-primary mt-3">Perbarui Status</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.starter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULI AH\Semester 5\Manpro\Tubes\website-hmif\resources\views/admin/voteStat.blade.php ENDPATH**/ ?>