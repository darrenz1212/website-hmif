<?php $__env->startSection('main-content'); ?>
    <div class="container my-5">
        <h1>Kelola Event</h1>

        
        <button class="btn btn-primary mb-3" onclick="toggleCreateForm()">Tambahkan Event</button>

        
        <table class="table">
            <thead>
            <tr>
                <th>#</th>
                <th>Nama Event</th>
                <th>Gambar</th>
                <th>Aksi</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($event->nama_event); ?></td>
                    <td><img src="<?php echo e(asset($event->img_path)); ?>" alt="Event Image" class="img-thumbnail" width="100"></td>
                    <td>
                        
                        <button class="btn btn-sm btn-info" onclick="toggleEditForm(<?php echo e($event); ?>)">Edit</button>

                        
                        <form action="<?php echo e(route('events.destroy', $event->event_id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-sm btn-danger">Hapus</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        
        <div id="create-form" style="display: none;">
            <h3>Tambah Event Baru</h3>
            <form action="<?php echo e(route('events.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <div class="form-group">
                    <label for="nama_event">Nama Event</label>
                    <input type="text" name="nama_event" class="form-control" required>
                </div>

                <div class="form-group">
                    <label for="img_path">Gambar</label>
                    <input type="file" name="img_path" class="form-control-file">
                </div>

                <button type="submit" class="btn btn-success">Simpan</button>
                <button type="button" class="btn btn-secondary" onclick="toggleCreateForm()">Batal</button>
            </form>
        </div>

        
        <div id="edit-form" style="display: none;">
            <h3>Edit Event</h3>
            <form id="editEventForm" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <input type="hidden" name="event_id" id="edit_event_id">

                <div class="form-group">
                    <label for="nama_event">Nama Event</label>
                    <input type="text" name="nama_event" id="edit_nama_event" class="form-control" required>
                </div>

                <div class="form-group">
                    <label for="img_path">Gambar</label>
                    <input type="file" name="img_path" class="form-control-file">
                </div>

                <button type="submit" class="btn btn-success">Update</button>
                <button type="button" class="btn btn-secondary" onclick="toggleEditForm()">Batal</button>
            </form>
        </div>
    </div>

    <script>
        function toggleCreateForm() {
            const createForm = document.getElementById('create-form');
            createForm.style.display = createForm.style.display === 'none' ? 'block' : 'none';
        }

        function toggleEditForm(event = null) {
            const editForm = document.getElementById('edit-form');
            editForm.style.display = editForm.style.display === 'none' ? 'block' : 'none';

            if (event) {
                // Isi form dengan data event yang akan diedit
                document.getElementById('edit_event_id').value = event.event_id;
                document.getElementById('edit_nama_event').value = event.nama_event;

                // Atur action form dengan route update sesuai event ID
                const editEventForm = document.getElementById('editEventForm');
                editEventForm.action = "<?php echo e(url('/events')); ?>/" + event.event_id;
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.starter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULI AH\Semester 5\Manpro\Tubes\website-hmif\resources\views/admin/editEvent.blade.php ENDPATH**/ ?>