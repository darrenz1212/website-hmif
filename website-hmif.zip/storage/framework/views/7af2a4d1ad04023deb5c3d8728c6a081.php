<?php $__env->startSection('main-home'); ?>
    <section class="container my-5 py-4">
        <div class="card shadow-lg p-4">
            <div class="card-body">
                <h1 class="card-title text-center"><?php echo e($news->judul); ?></h1>
                <p class="text-muted text-center">By <?php echo e($news->author); ?></p>
                <hr>

                <div class="text-center mb-4">
                    <img src="<?php echo e(asset($news->img_path)); ?>" alt="News Image" class="img-fluid rounded">
                </div>

                <div class="card-text">
                    <?php echo nl2br(e($news->artikel)); ?>

                </div>

                <div class="mt-4 text-center">
                    <a href="<?php echo e(route('home')); ?>" class="btn btn-primary">
                        <i class="fas fa-arrow-left"></i> Kembali ke Daftar Berita
                    </a>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.homeTemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULI AH\Semester 5\Manpro\Tubes\website-hmif\resources\views/news.blade.php ENDPATH**/ ?>