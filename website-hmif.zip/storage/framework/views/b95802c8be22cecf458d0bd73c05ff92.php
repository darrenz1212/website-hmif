<?php $__env->startSection('main-content'); ?>
    <table class="table">
        <thead>
        <tr>
            <th>Aspirasi</th>
            <th>Tanggal</th>
            <th>Action</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $aspiration; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($s->message); ?></td>
                <td><?php echo e($s-> created_at); ?></td>
                <td>
                    <button class="btn btn-danger btn-sm">Delete</button>
                </td>
            </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.starter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULI AH\Semester 5\Manpro\Tubes\website-hmif\resources\views/admin/showAspiration.blade.php ENDPATH**/ ?>