<?php $__env->startSection('main-home'); ?>
    <div class="container my-5 py-4">
        <h1 class="text-center mb-4 my-5">Pilih Ketua Himpunan Mahasiswa</h1>

        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php elseif(session('error')): ?>
            <div class="alert alert-danger">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>

        <div class="row">
            <?php $__currentLoopData = $candidates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $candidate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6 mb-4">
                    <div class="card shadow-lg">
                        <div class="card-body text-center">
                            <!-- Gambar Kandidat -->
                            <img src="<?php echo e(asset($candidate->image)); ?>" alt="<?php echo e($candidate->nama); ?>" class="img-fluid rounded-circle mb-3" style="width: 200px; height: 200px; object-fit: cover;">

                            <!-- Informasi Kandidat -->
                            <h3 class="card-title"><?php echo e($candidate->nama); ?></h3>
                            <p><strong>No Urut:</strong> <?php echo e($candidate->no_urut); ?></p>

                            <!-- Visi dan Misi -->
                            <div class="text-left">
                                <h5>Visi:</h5>
                                <p><?php echo e($candidate->visi); ?></p>
                                <h5>Misi:</h5>
                                <p><?php echo e($candidate->misi); ?></p>
                            </div>

                            <!-- Tombol Vote -->
                            <form action="<?php echo e(route('vote.cast', $candidate->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-primary btn-lg mt-3">Vote</button>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.homeTemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULI AH\Semester 5\Manpro\Tubes\website-hmif\resources\views/vote.blade.php ENDPATH**/ ?>