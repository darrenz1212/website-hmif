<?php $__env->startSection('main-content'); ?>
    <div class="container my-5">
        <h1>Hasil Penghitungan Suara</h1>

        <table class="table table-bordered">
            <thead>
            <tr>
                <th>No Urut</th>
                <th>Nama Kandidat</th>
                <th>Jumlah Vote</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $candidates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $candidate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($candidate->no_urut); ?></td>
                    <td><?php echo e($candidate->nama); ?></td>
                    <td><?php echo e($candidate->votes_count); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.starter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULI AH\Semester 5\Manpro\Tubes\website-hmif\resources\views/admin/voteCount.blade.php ENDPATH**/ ?>