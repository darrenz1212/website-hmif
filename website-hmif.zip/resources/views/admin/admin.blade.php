@extends('layouts.starter')

@section('main-content')
    <h1>Hello World</h1>
@endsection
