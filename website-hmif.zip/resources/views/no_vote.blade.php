@extends('layouts.homeTemplate')

@section('main-home')
    <section class="container my-5 py-4">
        <div class="row">
            <div class="col">
                <h1>Saat ini sedang tidak ada vote. Mohon tunggu Pemilihan Ketua Hima Berikutnya</h1>
            </div>
        </div>
    </section>
@endsection
